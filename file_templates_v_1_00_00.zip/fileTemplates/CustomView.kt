#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}

#end
#parse("File Header.java")
interface #parse("SnakeCaseToCamelCase.kt")Contract {

    interface UserAction {

        fun onAttachedToWindow()

        fun onDetachedFromWindow()
    }

    interface Screen {
    
    }
}