#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

class #parse("FolderToCamelCase.kt")RepositoryImpl : #parse("FolderToCamelCase.kt")Repository{
    
    override fun load(){
    
    }
}