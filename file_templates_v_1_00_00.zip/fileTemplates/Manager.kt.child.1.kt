#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

class #parse("FolderToCamelCase.kt")ManagerImpl : #parse("FolderToCamelCase.kt")Manager{
    
    private val listeners = ArrayList<#parse("FolderToCamelCase.kt")Manager.Listener>()

    override fun addListener(listener: #parse("FolderToCamelCase.kt")Manager.Listener) {
        if (listeners.contains(listener)) {
            return
        }
        listeners.add(listener)
    }

    override fun removeListener(listener: #parse("FolderToCamelCase.kt")Manager.Listener) {
        listeners.remove(listener)
    }
}