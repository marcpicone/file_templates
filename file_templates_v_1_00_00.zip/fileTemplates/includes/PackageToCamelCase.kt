#set($item = "")
#set($foreach = "")
#set($packageToCamelCase = "")
#foreach ($item in ${StringUtils.split(${PACKAGE_NAME},".")})
#if ($foreach.hasNext == false)
#set($packageToCamelCase = ${StringUtils.removeAndHump($item,"_")})
#end
#end
$packageToCamelCase