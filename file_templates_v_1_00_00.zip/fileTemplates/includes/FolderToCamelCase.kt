#set($folder = "")
#set($foreach = "")
#set($folderToCamelCase = "")
#foreach ($folder in ${StringUtils.split(${PACKAGE_NAME},".")})
#if ($foreach.hasNext == false)
#set($folderToCamelCase = ${StringUtils.removeAndHump($folder,"_")})
#end
#end
$folderToCamelCase