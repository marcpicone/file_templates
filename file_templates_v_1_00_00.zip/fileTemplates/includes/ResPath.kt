#set($folder = "")
#set($foreach = "")
#set($resRelativePath = "")
#set($endResPath = "../res")
#foreach ($folder in ${StringUtils.split(${PACKAGE_NAME},".")})
#set($resRelativePath = "$!resRelativePath../")
#if ($foreach.hasNext == false)
#set($resRelativePath = "$!resRelativePath$endResPath")
#end
#end
$resRelativePath