#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}

#end
#parse("File Header.java")
class #parse("SnakeCaseToCamelCase.kt")Presenter(
 private val screen : #parse("SnakeCaseToCamelCase.kt")Contract.Screen
) : #parse("SnakeCaseToCamelCase.kt")Contract.UserAction {

    override fun onAttachedToWindow(){
    
    }
    
     override fun onDetachedFromWindow(){
     
     }
}