#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

interface #parse("FolderToCamelCase.kt")Repository{

    fun load()
}