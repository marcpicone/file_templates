#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

class #parse("FolderToCamelCase.kt")Module {
    
    fun create#parse("FolderToCamelCase.kt")Manager () : #parse("FolderToCamelCase.kt")Manager {
        return #parse("FolderToCamelCase.kt")ManagerImpl()
    }
}